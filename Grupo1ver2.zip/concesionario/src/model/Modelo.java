package model;


public class Modelo {
   
    int IdModelo;
    String modelo;
   int IdMarca;
   String marca;
    
   
   public Modelo() {
    }

    public Modelo(int IdModelo, String modelo, int IdMarca, String marca) {
        this.IdModelo = IdModelo;
        this.modelo = modelo;
        this.IdMarca = IdMarca;
        this.marca = marca;
    }

    public int getIdModelo() {
        return IdModelo;
    }

    public void setIdModelo(int IdModelo) {
        this.IdModelo = IdModelo;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getIdMarca() {
        return IdMarca;
    }

    public void setIdMarca(int IdMarca) {
        this.IdMarca = IdMarca;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    
  
    
   
}
