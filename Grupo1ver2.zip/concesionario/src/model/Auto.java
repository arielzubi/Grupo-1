
package model;


public class Auto {
    int IdAuto;
    int IdMarca;
    int IdModelo;
    int IdVersion;
    int anio;
    Double precio;
    int kilometros;
    String combustible;
    int puertas;
    String condicion;
     String marca;
     String modelo;
     String version;
             
    public Auto() {
        
    }

    public Auto(int IdAuto, int IdMarca, int IdModelo, int IdVersion, int anio, Double precio, int kilometros, String combustible, int puertas, String condicion, String marca, String modelo, String version) {
        this.IdAuto = IdAuto;
        this.IdMarca = IdMarca;
        this.IdModelo = IdModelo;
        this.IdVersion = IdVersion;
        this.anio = anio;
        this.precio = precio;
        this.kilometros = kilometros;
        this.combustible = combustible;
        this.puertas = puertas;
        this.condicion = condicion;
        this.marca = marca;
        this.modelo = modelo;
        this.version = version;
    }

    public int getIdAuto() {
        return IdAuto;
    }

    public void setIdAuto(int IdAuto) {
        this.IdAuto = IdAuto;
    }

    public int getIdMarca() {
        return IdMarca;
    }

    public void setIdMarca(int IdMarca) {
        this.IdMarca = IdMarca;
    }

    public int getIdModelo() {
        return IdModelo;
    }

    public void setIdModelo(int IdModelo) {
        this.IdModelo = IdModelo;
    }

    public int getIdVersion() {
        return IdVersion;
    }

    public void setIdVersion(int IdVersion) {
        this.IdVersion = IdVersion;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public int getKilometros() {
        return kilometros;
    }

    public void setKilometros(int kilometros) {
        this.kilometros = kilometros;
    }

    public String getCombustible() {
        return combustible;
    }

    public void setCombustible(String combustible) {
        this.combustible = combustible;
    }

    public int getPuertas() {
        return puertas;
    }

    public void setPuertas(int puertas) {
        this.puertas = puertas;
    }

    public String getCondicion() {
        return condicion;
    }

    public void setCondicion(String condicion) {
        this.condicion = condicion;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    
}



   