
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class ModeloDao {
    //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;

 public ModeloDao() {
    }
    //Agregar editorial
    public boolean agregarModelo(Modelo modelo){
        String query = "INSERT INTO modelo (Modelo, idmarca ) VALUES(?,?)";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,modelo.getModelo());
            pst.setInt(2, modelo.getIdMarca());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar el modelo" + e);
            return false;
        }
    }
    
    //Modificar editorial
    public boolean modificarModelo(Modelo modelo){
        String query = "UPDATE modelo SET Modelo = ?, idmarca = ? WHERE idmodelo = ?";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,modelo.getModelo());
            pst.setInt(2, modelo.getIdMarca());
            pst.setInt(3, modelo.getIdModelo()); 
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar el modelo" + e);
            return false;
        }
    }

    //Borrar editorial
    public boolean borrarModelo(int id){
        String query = "DELETE FROM modelo WHERE idmodelo = " + id;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar el modelo" + e);
            return false;
        }
    }

    //Listar editorial
    public List listarModelo(){
        List<Modelo> list_modelos = new ArrayList();
        String query =  "SELECT mo.*, ma.marca, mo.modelo FROM modelo as mo inner join marca as ma on ma.idmarca = mo.idmarca ORDER BY marca ASC";
        
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Modelo modelo = new Modelo();
                modelo.setIdModelo(rs.getInt("idmodelo"));
                modelo.setModelo(rs.getString("modelo"));
                modelo.setIdMarca(rs.getInt("idmarca"));
                modelo.setMarca(rs.getString("marca"));
                list_modelos.add(modelo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_modelos;
    }    

    //Buscar id de editorial
    public int buscarIdModelo(String modelo){
        int id = 0;
        String query = "SELECT idmodelo FROM modelo WHERE Modelo = '" + modelo + "'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("idmodelo");            
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el id de modelo" + e);
        }
        return id;
    }
    
}


