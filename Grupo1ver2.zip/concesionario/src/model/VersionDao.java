
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class VersionDao {
    //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    
   
    public VersionDao() {
    }
    //Agregar autor
    public boolean agregarVersion(Version version){
        String query = "INSERT INTO version (version, idmodelo, idmarca ) VALUES(?,?,?)";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,version.getVersion());
            pst.setInt(2, version.getIdModelo());
            pst.setInt(3, version.getIdMarca());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar la version" + e);
            return false;
        }
    }
    
    //Modificar autor
    public boolean modificarVersion(Version version){
        String query = "UPDATE version SET version = ?, idmodelo = ?, idmarca = ? WHERE idversion = ?";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
             
             pst.setString(1,version.getVersion());
            
            pst.setInt(2, version.getIdModelo());
            pst.setInt(3, version.getIdMarca());
             pst.setInt(4, version.getIdVersion());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar la version" + e);
            return false;
        }
    }

    //Borrar autor
    public boolean borrarVersion(int id){
        String query = "DELETE FROM version WHERE idversion = " + id;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar la version" + e);
            return false;
        }
    }

    //Listar autor
    public List listarVersion(){
        List<Version> list_version = new ArrayList();
        String query = "SELECT ver.*, mar.marca, mo.modelo FROM version as ver inner join modelo as mo on ver.idmodelo = mo.idmodelo inner join marca as mar on ver.idmarca = mar.idmarca  ORDER BY marca ASC";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Version version = new Version();
                version.setIdVersion(rs.getInt("idVersion"));
                version.setVersion(rs.getString("version"));
                version.setIdMarca(rs.getInt ("idMarca"));
                version.setMarca(rs.getString("marca"));
                version.setIdModelo(rs.getInt("IdModelo"));
                version.setModelo(rs.getString("modelo"));
                
                list_version.add(version);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_version;
    }    
    
    //Buscar id de autor
    public int buscarIdVersion(String version){
        int id = 0;
        String query = "SELECT idversion FROM version WHERE version = '" + version + "'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("idVersion");            
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el id de version" + e);
        }
        return id;
    }

}







