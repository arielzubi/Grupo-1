package model;


public class Version {
   
    int IdVersion;
    int IdMarca;
    String version;
    String marca;
    int IdModelo;
    String modelo;

    public Version() {
    }

    public Version(int IdVersion, int IdMarca, String version, String marca, int IdModelo, String modelo) {
        this.IdVersion = IdVersion;
        this.IdMarca = IdMarca;
        this.version = version;
        this.marca = marca;
        this.IdModelo = IdModelo;
        this.modelo = modelo;
    }

    public int getIdVersion() {
        return IdVersion;
    }

    public void setIdVersion(int IdVersion) {
        this.IdVersion = IdVersion;
    }

    public int getIdMarca() {
        return IdMarca;
    }

    public void setIdMarca(int IdMarca) {
        this.IdMarca = IdMarca;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getIdModelo() {
        return IdModelo;
    }

    public void setIdModelo(int IdModelo) {
        this.IdModelo = IdModelo;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    
}

    