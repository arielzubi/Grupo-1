
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Auto;
import model.AutoDao;
import view.Pantalla;
import model.Marca;
import model.MarcaDao;
import model.Modelo;
import model.ModeloDao;
import model.Version;
import model.VersionDao;
        
public class AutoControlador implements ActionListener, MouseListener, KeyListener {
    private Auto auto;
    private AutoDao autoDao;
    private Pantalla panta;
    private Marca marca;
    private MarcaDao marcaDao;
    private Modelo modelo;
    private ModeloDao modeloDao;
    private Version version;
    private VersionDao versionDao;
        
    DefaultTableModel model = new DefaultTableModel();

    public AutoControlador(Auto auto, AutoDao autoDao, Pantalla panta) {
        this.auto = auto;
        this.autoDao = autoDao;
        this.panta = panta;
        
        //Botón de registrar autor
        this.panta.btn_Agregar_Auto.addActionListener(this);
        //Botón de modificar autor
        this.panta.btn_Modificar_Auto.addActionListener(this);
        //Botón de borrar autor
        this.panta.btn_Borrar_Auto.addActionListener(this);
        //Botón de limpiar
        this.panta.btn_Limpiar_Auto.addActionListener(this);
        
        //Listado de autor
        this.panta.tb_Auto.addMouseListener(this);
              
        listarAutos(); 
        
    }

    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == panta.btn_Agregar_Auto){
            //verifica si el campo nombre está vacío
            if(panta.txt_Anio_Auto.getText().equals("")){
                JOptionPane.showMessageDialog(null, "El campo Año es obligatorio");
            }else{
                //Realiza el agregado
                
                auto.setKilometros(Integer.parseInt(panta.txt_Kilometros_Auto.getText()));
                auto.setAnio(Integer.parseInt(panta.txt_Anio_Auto.getText()));
                auto.setPrecio(Double.parseDouble(panta.txt_Precio_Auto.getText()));
                
                auto.setPuertas(Integer.parseInt(panta.spn_puertas.getValue().toString()));
                
                int idMarca= marcaDao.buscarIdMarca(panta.cmb_Marca.getSelectedItem().toString());
                int idModelo= modeloDao.buscarIdModelo(panta.cmb_Modelo.getSelectedItem().toString());
                int idVersiono= versionDao.buscarIdVersion(panta.cmb_Version.getSelectedItem().toString());
                
                if(panta.chk_condicion.isSelected()){
                    auto.setCondicion("nuevo");
                }else{
                auto.setCondicion("usado");
            }
               if (panta.rb_nafta.isSelected()){
                   auto.setCombustible("nafta");
               }else if(panta.rb_gasoil.isSelected()){
                   auto.setCombustible("gasoil");
               }else if(panta.rb_gnc.isSelected()){
                           
               }
                
                if(autoDao.agregarAuto(auto)){
                    limpiarTabla();
                    limpiarCampos();
                    listarAutos();
                    JOptionPane.showMessageDialog(null, "Se agregó el auto");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar el auto");
                }
            }
        }else if(e.getSource() == panta.btn_Modificar_Auto){
            //verifica si el campo id está vacío
            if(panta.txt_Id_Auto.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza la modificación
                auto.setIdauto(Integer.parseInt(panta.txt_Id_Auto.getText()));
                auto.setNombreAuto(panta.txt_Auto.getText());
                if(autoDao.modificarAuto(auto)){
                    limpiarTabla();
                    limpiarCampos();
                    listarAutos();
                    JOptionPane.showMessageDialog(null, "Se modificó el auto");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar el auto");
                }
            }
        }else if(e.getSource() == panta.btn_Borrar_Auto){
            //verifica si el campo id está vacío
            if(panta.txt_Id_Auto.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza el borrado
                int id = Integer.parseInt(panta.txt_Id_Auto.getText());
                if(autoDao.borrarAuto(id)){
                    limpiarTabla();
                    limpiarCampos();
                    listarAutos();
                    JOptionPane.showMessageDialog(null, "Se eliminó el auto");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar el auto");
                }
            }
        }else if(e.getSource() == panta.btn_Limpiar_Auto){
                limpiarTabla();
                limpiarCampos();
                listarAutos();    
                panta.btn_Agregar_Auto.setEnabled(true);
        }    
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(e.getSource() == panta.tb_Auto){
            int row = panta.tb_Auto.rowAtPoint(e.getPoint());
            panta.txt_Id_Auto.setText(panta.tb_Auto.getValueAt(row,0).toString());
            panta.txt_Auto.setText(panta.tb_Auto.getValueAt(row,1).toString());
            //Deshabilitar
            panta.btn_Agregar_Auto.setEnabled(false);
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    //Listar todos los autores
    public void listarAutos(){
 

        panta.cmb_Marca.removeAllItems();

        List<Marca> list = marcaDao.listarMarca();
        model = (DefaultTableModel) panta.tb_Marca.getModel();
        Object[] row = new Object[2];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getIdmarca();
            row[1] = list.get(i).getMarca();
            model.addRow(row);
            panta.cmb_Marca.addItem(list.get(i).getMarca());
        }
        
    }


    //Limpiar la tabla
    public void limpiarTabla(){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_Id_Auto.setText("");
        panta.txt_Auto.setText("");
    }
    
}
 
    

