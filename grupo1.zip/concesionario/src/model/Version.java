package model;


import java.sql.CallableStatement;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.sql.Statement;
import java.sql.ResultSet;


public class Version {
   
    int idVersion;
    String version;

    public Version() {
    }

    public Version(int idVersion, String version) {
        this.idVersion = idVersion;
        this.version = version;
    }

    public int getIdVersion() {
        return idVersion;
    }

    public void setIdVersion(int idVersion) {
        this.idVersion = idVersion;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }
    
    

}